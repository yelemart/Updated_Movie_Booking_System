const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// POST endpoint to create a booking
app.post('/api/bookings', (req, res) => {
    const bookingData = req.body;

    // Format the booking data as a string
    const bookingString = `Name: ${bookingData.name}, Email: ${bookingData.email}, Movie: ${bookingData.movie}, Seats: ${bookingData.seats.join(', ')}, Payment Method: ${bookingData.paymentMethod}\n`;

    // Append the booking data to a text file
    fs.appendFile('bookings.txt', bookingString, (err) => {
        if (err) {
            return res.status(500).send('Error saving booking data');
        }
        res.status(201).send('Booking saved successfully');
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
}); console.log(`Server is running on http://localhost:${PORT}`);
