<?php
include 'db.php';

$query = $pdo->query("SELECT * FROM movies");
$movies = $query->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($movies);
?>