# Movie Seat Booking Application

## How to Run the Code

1. Open the `index.html` file in your web browser.
2. Select a movie from the dropdown.
3. Click on available seats to select them.
4. The selected seat count will be displayed.
5. Click "Proceed to Payment" to continue.

Expect a confirmation message and you're done!