<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $movie = $_POST['movie'];
    $seats = $_POST['seats'];
    $paymentMethod = $_POST['paymentMethod'];

    // Format the booking data as a string
    $bookingString = "Name: $name\nEmail: $email\nMovie: $movie\nSeats: $seats\nPayment Method: $paymentMethod\n\n";

    // Append the booking data to a text file
    file_put_contents('bookings.txt', $bookingString, FILE_APPEND);
    echo "Booking saved successfully!";
}
?>