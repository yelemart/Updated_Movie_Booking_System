const fs = require('fs');

/**
 * Collects user data and appends it to a JSON file.
 * @param {string} name - The name of the user.
 * @param {string} email - The email of the user.
 * @param {string} movie - The selected movie.
 * @param {Array<number>} seats - The selected seat numbers.
 */
function collectData(name, email, movie, seats) {
    const data = {
        name,
        email,
        movie,
        seats,
        timestamp: new Date().toISOString() // Capture the current timestamp
    };

    // Read existing data
    fs.readFile('data_collection.json', 'utf8', (err, fileData) => {
        let jsonData = [];
        if (!err && fileData) {
            try {
                jsonData = JSON.parse(fileData); // Parse existing data
            } catch (parseError) {
                console.error('Error parsing JSON:', parseError);
            }
        }
        jsonData.push(data); // Add new data
        fs.writeFile('data_collection.json', JSON.stringify(jsonData, null, 2), (err) => {
            if (err) throw err;
            console.log('Data collected successfully!');
        });
    });
}

// Example usage
collectData('Skippy Morris', 'Skipmore@example.com', 'Wicked', [2, 3, 4]);