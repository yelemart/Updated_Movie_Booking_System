<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debug: Check if data is received
    echo "Form submitted. <br>";

    // Collect the form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $paymentMethod = htmlspecialchars($_POST['payment-method']);

    // Debug: Output the received data
    echo "Name: $name <br>";
    echo "Email: $email <br>";
    echo "Payment Method: $paymentMethod <br>";

    // Prepare the data to be saved
    $data = "Name: $name, Email: $email, Payment Method: $paymentMethod\n";

    // Save the data to a text file
    $file = 'payments.txt';
    if (file_put_contents($file, $data, FILE_APPEND | LOCK_EX) === false) {
        echo "Error writing to file."; // This will display if there was an error
    } else {
        echo "Payment information submitted successfully!"; // This will display if the write was successful
    }
} else {
    echo "Invalid request method."; // This will display if the request method is not POST
}
?>