<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $movie_id = $_POST['movie_id'];
    $seat_number = $_POST['seat_number'];

    $stmt = $pdo->prepare("INSERT INTO bookings (movie_id, seat_number) VALUES (?, ?)");
    $stmt->execute([$movie_id, $seat_number]);

    echo json_encode(['status' => 'success', 'message' => 'Booking successful!']);
}
?>