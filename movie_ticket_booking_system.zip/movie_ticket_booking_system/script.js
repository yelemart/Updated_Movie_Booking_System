const container = document.querySelector('.container');
const seatRowsContainer = document.getElementById('seat-rows');
const count = document.getElementById('count');
const movieSelect = document.getElementById('movie');
const movieTitle = document.getElementById('movie-title');
const movieSynopsis = document.getElementById('movie-synopsis');
const movieRating = document.getElementById('movie-rating');
const movieGenre = document.getElementById('movie-genre');
const paymentButton = document.getElementById('payment-button');

// Initialize seats data and movie info
let seatsData = JSON.parse(movieSelect.options[movieSelect.selectedIndex].dataset.seats);
let movieInfo = {
    synopsis: movieSelect.options[movieSelect.selectedIndex].dataset.synopsis,
    rating: movieSelect.options[movieSelect.selectedIndex].dataset.rating,
    genre: movieSelect.options[movieSelect.selectedIndex].dataset.genre
};

// Function to generate random seating availability
function generateRandomSeats(totalSeats, soldCount) {
    const availableSeats = [];
    const soldSeats = [];
    
    for (let i = 1; i <= totalSeats; i++) {
        availableSeats.push(i);
    }

    // Randomly select sold seats
    while (soldSeats.length < soldCount) {
        const randomIndex = Math.floor(Math.random() * totalSeats);
        const seatNumber = availableSeats[randomIndex];
        if (!soldSeats.includes(seatNumber)) {
            soldSeats.push(seatNumber);
            availableSeats.splice(randomIndex, 1); // Remove from available
        }
    }

    return {
        available: availableSeats,
        sold: soldSeats,
        selected: []
    };
}

// Function to render seats based on availability
function renderSeats() {
    seatRowsContainer.innerHTML = ''; // Clear previous seats
    const totalRows = 6; // Total number of rows
    const seatsPerRow = 5; // Number of seats per row

    for (let rowIndex = 0; rowIndex < totalRows; rowIndex++) {
        const row = document.createElement('div');
        row.classList.add('row');

        const soldCount = Math.floor(Math.random() * 3); // Randomly generate sold seats count
        seatsData = generateRandomSeats(seatsPerRow, soldCount); // Generate random seat data

        // Create seat elements
        for (let seatIndex = 1; seatIndex <= seatsPerRow; seatIndex++) {
            const seat = document.createElement('div');
            seat.classList.add('seat');
            seat.dataset.seatNumber = seatIndex + (rowIndex * seatsPerRow); // Calculate seat number

            if (seatsData.sold.includes(seatIndex)) {
                seat.classList.add('sold');
            } else if (seatsData.available.includes(seatIndex)) {
                seat.classList.add('available');
            }

            seat.addEventListener('click', () => {
                if (!seat.classList.contains('sold')) {
                    seat.classList.toggle('selected');
                    updateSelectedCount();
                }
            });

            row.appendChild(seat);
        }

        seatRowsContainer.appendChild(row); // Append the row to the container
    }
}

// Update selected seat count
function updateSelectedCount() {
    const selectedSeats = document.querySelectorAll('.row .seat.selected');
    const selectedSeatsCount = selectedSeats.length;
    count.innerText = selectedSeatsCount;
}

// Update movie information
function updateMovieInfo() {
    movieTitle.textContent = movieSelect.value;
    movieSynopsis.textContent = movieInfo.synopsis;
    movieRating.textContent = movieInfo.rating;
    movieGenre.textContent = movieInfo.genre;
}

// Movie select event
movieSelect.addEventListener('change', e => {
    seatsData = JSON.parse(e.target.options[e.target.selectedIndex].dataset.seats);
    movieInfo = {
        synopsis: e.target.options[e.target.selectedIndex].dataset.synopsis,
        rating: e.target.options[e.target.selectedIndex].dataset.rating,
        genre: e.target.options[e.target.selectedIndex].dataset.genre
    };
    renderSeats();
    updateMovieInfo();
});

// Payment button click event
paymentButton.addEventListener('click', () => {
    const selectedSeats = document.querySelectorAll('.row .seat.selected');
    const selectedSeatsCount = selectedSeats.length;

    if (selectedSeatsCount === 0) {
        alert("Please select at least one seat to proceed with payment.");
        return;
    }

    // Show the payment form
    document.getElementById('payment-form').style.display = 'block';
    paymentButton.style.display = 'none'; // Optionally hide the payment button
});

// Handle payment form submission
document.getElementById('payment-info').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent the default form submission

    const selectedSeats = Array.from(document.querySelectorAll('.row .seat.selected')).map(seat => parseInt(seat.dataset.seatNumber));
    const selectedSeatsCount = selectedSeats.length;
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const paymentMethod = document.getElementById('payment-method').value;

    // Prepare data to send to the server
    const bookingData = {
        name,
        email,
        movie: movieSelect.value,
        seats: selectedSeats,
        paymentMethod
    };

    // Simulate successful payment directly
    alert("Payment successful! Your booking details will be sent to your email.");
    
    // Reset the form and selected seats
    document.getElementById('payment-form').reset();
    document.getElementById('payment-form').style.display = 'none';
    document.querySelectorAll('.row .seat.selected').forEach(seat => seat.classList.remove('selected'));
    updateSelectedCount();
});

// Initial render
renderSeats();
updateMovieInfo();