# Unit Testing for Movie Seat Booking Application
# Integration testing 
$ Data collection

## How to the tests

1. First. Make sure Node.js installed.
2. Open the project folder in a code editor (preferably Visual Studio Code).
3. Install Jest by running the following command in the terminal:

Run the tests using 'npm test' command.
The tests should run, and you will see the results in the terminal.