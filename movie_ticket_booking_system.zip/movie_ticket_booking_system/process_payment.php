<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $booking_id = $_POST['booking_id'];
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];

    $stmt = $pdo->prepare("INSERT INTO payments (booking_id, amount, payment_method) VALUES (?, ?, ?)");
    $stmt->execute([$booking_id, $amount, $payment_method]);

    echo json_encode(['status' => 'success', 'message' => 'Payment processed successfully!']);
}
?>